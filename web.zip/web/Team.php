<?php
	include 'Code.php';
	$menu=loadFile("Menu2.html");
	$team=loadFile("Team.html");
	$footer=loadFile("Footer.html");
	$data = $menu.$team.$footer;
	echo "$data";
?>