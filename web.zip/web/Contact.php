<?php
	include 'Code.php';
	$menu=loadFile("Menu2.html");
	$mail=loadFile("Mail.html");
	$footer=loadFile("Footer.html");
	$data = $menu.$mail.$footer;
	echo "$data";
?>