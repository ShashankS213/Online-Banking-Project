<?php
	include 'Code.php';
	$menu=loadFile("menu.html");
	$about=loadFile("About.html");
	$footer=loadFile("Footer.html");
	$data = $menu.$about.$footer;
	echo "$data";
?>