<?php
	session_start();
	include 'Code.php';
	$menu=loadFile("menu.html");
	$register=loadFile("Register.html");
	$footer=loadFile("Footer.html");
	$data = $menu.$register.$footer;
	echo "$data";
	if(isset($_SESSION['error2'])){
		$error = $_SESSION['error2'];
		echo '<script language="javascript">';
		echo 'alert("Email already exist!!!")';
		echo '</script>';
		session_destroy();
	}
?>