<?php
	function loadFile($fname)
	{
		$content = file_get_contents('Blocks/'.$fname);
		return $content;
	}


	function runQuery($q)
	{
		$con=mysqli_connect("localhost","root","");
		mysqli_select_db($con,"projectphp");
		$result=mysqli_query($con, $q);
		mysqli_close($con);
		return $result;
	}
?>