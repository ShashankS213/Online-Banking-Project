<?php
	include 'Code.php';
	$menu=loadFile("Menu2.html");
	$gallery=loadFile("Gallery.html");
	$footer=loadFile("Footer.html");
	$data = $menu.$gallery.$footer;
	echo "$data";
?>