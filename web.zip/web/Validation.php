<?php
	session_start();
	include 'Code.php';
	$mail=$_POST['email'];
	$password=$_POST['pass'];
	$query = "select * from user where  mail='$mail' && password='$password'";
	$res = runQuery($query);
	$num=mysqli_num_rows($res);
	if($num==1)
	{
		$qu = "select name from user where mail = '$mail'";
		$res2 = runQuery($qu);
		$row = mysqli_fetch_row($res2);
		$_SESSION['uid'] = $mail;
		$_SESSION['uname'] = $row[0];
		header('location:http://localhost/Project_php/web/User.php');
	}
	else
	{
		$_SESSION['error'] = "Email or password incorrect...";
		header('location:http://localhost/Project_php/web/Login.php');
	}
?>