<?php
	session_start();
	include "Code.php";
	$menu=loadFile("menu.html");
	$login=loadFile("Login.html");
	$footer=loadFile("Footer.html");
	$data = $menu.$login.$footer;
	echo "$data";
	if(isset($_SESSION['error'])){
		$error = $_SESSION['error'];
		echo '<script language="javascript">';
		echo 'alert("Username or password incorrect...")';
		echo '</script>';
		session_destroy();
	}
?>