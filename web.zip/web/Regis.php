<?php
	session_start();
	include "Code.php";
	$uname=$_POST['name'];
	$mail=$_POST['email'];
	$number=$_POST['number'];
	$password=$_POST['pass'];
	$query = "INSERT INTO user (name, mail, number, password) VALUES ('$uname', '$mail', '$number', '$password')";
	$res = runQuery($query);
	if($res)
	{
		echo "Registered Successfully";
		$_SESSION['uid'] = $mail;
		$_SESSION['uname'] = $uname;
		header('location:http://localhost/Project_php/web/User.php');
	}
	else{
		$_SESSION['error2'] = "User already exist!!!";
		header('location:http://localhost/Project_php/web/Register.php');
	}
?>