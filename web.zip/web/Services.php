<?php
	include 'Code.php';
	$menu=loadFile("Menu2.html");
	$services=loadFile("Service.html");
	$footer=loadFile("Footer.html");
	$data = $menu.$services.$footer;
	echo "$data";
?>