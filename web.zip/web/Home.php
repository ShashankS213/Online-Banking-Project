<?php
	include 'Code.php';
	$menu=loadFile("menu.html");
	$banner=loadFile("Banner.html");
	$footer=loadFile("Footer.html");
	$data = $menu.$banner.$footer;
	echo "$data";
?>