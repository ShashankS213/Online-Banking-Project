<?php
	session_start();
	include 'Code.php';
	if (!(isset($_SESSION['uid']) && $_SESSION['uid'] != '')) 
	{
		header('location:http://localhost/Project_php/web/Login.php');
	}
	else{
		$menu=loadFile("Menu2.html");
		$user=loadFile("User.html");
		$footer=loadFile("Footer.html");
		$data = $menu.$user.$footer;
		echo sprintf($data, $_SESSION['uname']);
	}
?>