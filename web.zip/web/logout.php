<?php
session_start();
session_destroy();
header('location:http://localhost/Project_php/web/Login.php');
?>